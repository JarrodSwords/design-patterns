﻿namespace DesignPatterns.Sandbox;

public enum WaveType
{
    Email,
    Mail,
    Phone
}
