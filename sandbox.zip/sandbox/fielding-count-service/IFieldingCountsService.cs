﻿namespace DesignPatterns.Sandbox;

public interface IFieldingCountsService
{
}
