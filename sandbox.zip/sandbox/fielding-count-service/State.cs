﻿namespace DesignPatterns.Sandbox;

public abstract class State
{
    protected readonly IFieldingCountsRepository Repo;

    protected State(IFieldingCountsRepository repo)
    {
        Repo = repo;
    }

    public State ChangeState(int cahpsTypeId, IFieldingCountsRepository repo) =>
        cahpsTypeId switch
        {
            13 => new McahpsState(repo),
            15 => new QhpState(repo),
            16 => new HosState(repo)
        };

    public abstract IEnumerable<long> GetSurveyIds(CahpsDataRequestParameters args);
    public abstract WaveTypeQuantity GetUndeliverableCount(CahpsDataRequestParameters args);
    public abstract void ValidateArgs(CahpsDataRequestParameters args);
}
