﻿namespace DesignPatterns.Sandbox.ordering;

public record LineItem;
