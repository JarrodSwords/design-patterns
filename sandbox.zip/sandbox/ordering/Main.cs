﻿namespace DesignPatterns.Sandbox.ordering;

public class Main
{
    public void Run()
    {
        var order = new Order();

        order.AddLineItem(new LineItem());
        order.AddLineItem(new LineItem());
        order.RemoveLineItem(Guid.NewGuid());
        order.Cancel();
    }
}
