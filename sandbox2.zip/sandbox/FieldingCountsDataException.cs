﻿namespace DesignPatterns.Sandbox;

public class FieldingCountsDataException : Exception
{
    public FieldingCountsDataException(string requestsForMcahpsMustIncludeAProjectId)
    {
        throw new NotImplementedException();
    }
}
