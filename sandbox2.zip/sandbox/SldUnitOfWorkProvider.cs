﻿namespace DesignPatterns.Sandbox;

public class SldUnitOfWorkProvider
{
    public IDisposable StartUnitOfWork(int argsCahpsTypeId) => throw new NotImplementedException();
}
