﻿namespace DesignPatterns.Sandbox.ordering;

public record PaymentDetails;
